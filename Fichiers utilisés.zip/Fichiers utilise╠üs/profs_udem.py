# coding: utf-8

import csv
import requests
from bs4 import BeautifulSoup

fichier = "prof_udem5.csv"

entete = {
	"User-Agent": "Olivier Faucher - requête acheminée dans le cadre d'un cours de journalisme de données",
	"From":"faucher.olivier@courrier.uqam.ca"
	}

for numdepage in range(1,24):
	url = f"https://recherche.umontreal.ca/nos-chercheurs/repertoire-des-professeurs/sm/l/pg/{numdepage}"
	print(url)


	contenu = requests.get(url,headers=entete)

	page = BeautifulSoup(contenu.text,"html.parser")

	professeurs = page.find_all("div", class_="row udemvitrine-search-result")


	with open(fichier,"w") as f2:
		creation_fichier = csv.writer(f2,)
		for professeur in professeurs:
			href = professeur.find("a")["href"] #Trouver le lien de la page d'un prof
			enseignants = "https://recherche.umontreal.ca" + href #Compléter la page
			contenu2 = requests.get(enseignants,headers=entete) #Accéder à la page
			page_prof = BeautifulSoup(contenu2.text, "html.parser") #Lire la page

			coordonnees = page_prof.find("dd", class_="uniteAdministrative") #Ceci est la section des coordonnées du prof

			infos = []

			