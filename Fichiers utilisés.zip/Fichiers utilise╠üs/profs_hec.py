# # coding: utf-8

import csv
import requests
from bs4 import BeautifulSoup

fichier = "profs_hec.csv"

entete = {
	"User-Agent": "Olivier Faucher - requête acheminée dans le cadre d'un cours de journalisme de données",
	"From":"faucher.olivier@courrier.uqam.ca"
	}

url = "https://www.hec.ca/profs/"

contenu = requests.get(url,headers=entete)

page = BeautifulSoup(contenu.text.encode("latin-1").decode("utf-8"),"html.parser")

departements = page.find("div", id="br-123383").find_next("ul").find_all("li")

with open(fichier,"w") as f2:
	creation_fichier = csv.writer(f2,)
	for departement in departements:
		lien_depart = departement.find("a")["href"] #trouver le lien de chaque département
		acces = requests.get(lien_depart,headers=entete) #Accéder à la page
		page_départ = BeautifulSoup(acces.text, "html.parser") #Lire la page

		#Arrivé(e)s sur la page d'un département!
		section_profs = page_départ.find("div", class_="ALBOfProfs") #Section des profs
		professeurs = section_profs.find_all("div", class_="row") #trouver les profs

		#Accéder à la page prof
		for professeur in professeurs:
			infos = []
			lien_page_prof = professeur.find("div", class_="col-sm-4").find("a")["href"]
			acces_prof = requests.get(lien_page_prof,headers=entete)
			page_prof = BeautifulSoup(acces_prof.text.encode("latin-1").decode("utf-8"), "html.parser")


			#Créer la colonne qui nomme le HEC
			infos.append("HEC Montréal")

			#Arrivé(e)s sur la page du prof!

			#Rammasse le nom du prof
			section_info = page_prof.find("div", class_="container", id="LeContenu")
			nom_prof2 = section_info.find("h1").text
			infos.append(nom_prof2)
			print(nom_prof2)

			#Genre (Professeur ou Professeure)
			genre = section_info.find("h2").text
			genre2 = genre.split(",")[0]
			genre3 = genre2.split()[0]
			if not genre3 == "Attachée": #Retirer le poste d'attaché(e)
				if not genre3 == "Attaché":
					infos.append(genre3)


					#Rammasse le département
					departement = section_info.find("h2").text 
					departement2 = departement.split(",")
					departement3 = departement2[1].strip()
					infos.append(departement3)


					#Rammasse Le courriel
					courriel = section_info.find("div", class_="col-sm-4")
					courriel2 = courriel.find("a", class_="hTypeMenu").text
					infos.append(courriel2)


					#Rammasse le numéro de téléphone
					tel = courriel.find_all("a", class_="hTypeMenu")[1].text
					infos.append(tel)


					#Rammasse l'expertise
					exp = section_info.find("div", class_="col-sm-8")
					#print(exp.text)
					h3 = exp.find_all("h3")
					for item in h3:
						#print(item)
						if "Expertise" in item.text:
							expertises = item.find_next("ul").find_all("li")
							#print(expertises)
							e = []
							for expertise in expertises:
								e.append(expertise.text.strip())
								# print(expertise.text)
							infos.append(e)

					# exp2 = page_prof.find_all("div")
					# # print(exp2)
					# for item in exp2:
					# 	if " Expertise " in item.text:
					# 		expertise = item.find_all("li")
					# 		print(expertise)






					#Rammasse le lien du site du prof
					infos.append(lien_page_prof)

					print(professeur)




			

			


