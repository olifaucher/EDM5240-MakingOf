# # coding: utf-8

import csv
import requests
from bs4 import BeautifulSoup

fichier = "profs_poly.csv"

entete = {
	"User-Agent": "Olivier Faucher - requête acheminée dans le cadre d'un cours de journalisme de données",
	"From":"faucher.olivier@courrier.uqam.ca"
	}

liens_depart = "https://www.polymtl.ca/bottin/unites/52"
contenu = requests.get(liens_depart,headers=entete)
page = BeautifulSoup(contenu.text,"html.parser")
div_departement = page.find("ul", class_="bottin")
departements = div_departement.find_all("li")
n = 0

for departement in departements:
	lien_departement = departement.find("a")["href"]	
	url_departement = "https://www.polymtl.ca" + lien_departement
	contenu2 = requests.get(url_departement,headers=entete)
	page_depart = BeautifulSoup(contenu2.text,"html.parser")
	
	#print(lien_departement)

	 #Va chercher les lignes du tableau
	t = page_depart.find("tbody").find_all("tr")


	#Filtre pour aller chercher les profs seulement
	for t4 in t:
		genre = t4.find_next("td").text
		if "Professeur" in t4.find_next("td").text:
			genre3 = genre.split()[0]
			n += 1
			#print(n, genre3,)
			
			elements = t4.find_all("td")
			#print(n, elements)
			for el in elements:
				lienPageProfs = el.find_all("a")
				print(lienPageProfs)

				#lien_prof = t4.find_next("td")
				#lien_prof2 = genre.find_next("td")
				#lien_prof3 = lien_prof2.find("a")["href"]
				#print(lien_prof3)













	





